const express = require("express");
const mysql = require("mysql2/promise"); // Use mysql2 with promise
const cors = require("cors");
const bodyParser = require("body-parser");
const nodemailer = require("nodemailer");
const path = require("path");
const Razorpay = require("razorpay");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public"))); // To serve static HTML/CSS/JS

// ✅ MySQL config for local XAMPP
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '', // default in XAMPP is empty password
  database: 'JAYAVARAD_Graphics_db',
  port: 3306
};

let db;
mysql.createConnection(dbConfig).then(connection => {
  db = connection;
  console.log("✅ MySQL Connected (Localhost/XAMPP).");
}).catch(err => {
  console.error("❌ MySQL connection failed:", err);
});

// Nodemailer setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'abhilashdeveloper07@gmail.com',
    pass: 'crnn rutm ugtp spfw' // Gmail App Password
  }
});

// ✅ Feedback API
app.post("/api/feedback", async (req, res) => {
  const { name, phone, email, message } = req.body;

  try {
    await db.execute(
      "INSERT INTO feedback (name, phone, email, message) VALUES (?, ?, ?, ?)",
      [name, phone, email, message]
    );
    res.status(200).json({ message: "✅ Feedback submitted successfully." });
  } catch (err) {
    console.error("❌ Feedback DB error:", err);
    res.status(500).json({ message: "Database error." });
  }
});

// ✅ 6 Rod Order API
app.post("/api/6rodorder", async (req, res) => {
  const { productCode, name, email, phone, quantity, address } = req.body;

  if (!productCode || !name || !email || !phone || !quantity || !address) {
    return res.status(400).json({ message: '⚠️ All fields are required.' });
  }

  try {
    await db.execute(
      'INSERT INTO orders_6rod (product_code, name, email, phone, quantity, address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [productCode, name, email, phone, quantity, address]
    );

   const mailOptions = {
  from: 'abhilashdeveloper07@gmail.com',
  to: email,
  subject: 'Order Confirmation - JV Indians',
  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #ddd; padding: 20px; border-radius: 8px; background-color: #f9f9f9;">
      <h2 style="color: #004080; text-align: center;">JV Indians - Order Confirmation</h2>

      <p style="font-size: 16px;">Hello <strong>${name}</strong>,</p>

      <p style="font-size: 15px;">
        Thank you for placing your order with <strong>JV Indians</strong>. We’ve received your order and will process it soon.
      </p>

      <h3 style="color: #333;">📦 Order Details</h3>
      <ul style="list-style: none; padding-left: 0; font-size: 15px;">
        <li><strong>🧾 Product Code:</strong> ${productCode}</li>
        <li><strong>📞 Phone:</strong> ${phone}</li>
        <li><strong>📧 Email:</strong> ${email}</li>
        <li><strong>📦 Quantity:</strong> ${quantity}</li>
        <li><strong>🏠 Address:</strong> ${address}</li>
      </ul>

      <p style="font-size: 15px;">We’ll get back to you soon!</p>

      <p style="margin-top: 30px; font-size: 14px; color: #666;">
        Regards,<br/>
        <strong>JV Indians Team</strong>
      </p>
    </div>
  `
};


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('❌ Email error:', error);
        return res.status(500).json({ message: 'Order saved, but email failed to send.' });
      }
      res.status(200).json({ message: '✅ Order placed and confirmation email sent.' });
    });

  } catch (err) {
    console.error('❌ Order DB error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});


// ✅ 7 Rod Order API
app.post("/api/7rodorder", async (req, res) => {
  const { productCode, name, email, phone, quantity, address } = req.body;

  if (!productCode || !name || !email || !phone || !quantity || !address) {
    return res.status(400).json({ message: '⚠️ All fields are required.' });
  }

  try {
    await db.execute(
      'INSERT INTO orders_7rod (product_code, name, email, phone, quantity, address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [productCode, name, email, phone, quantity, address]
    );

   const mailOptions = {
  from: 'abhilashdeveloper07@gmail.com',
  to: email,
  subject: 'Order Confirmation - JV Indians',
  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #ddd; padding: 20px; border-radius: 8px; background-color: #f9f9f9;">
      <h2 style="color: #004080; text-align: center;">JV Indians - Order Confirmation</h2>

      <p style="font-size: 16px;">Hello <strong>${name}</strong>,</p>

      <p style="font-size: 15px;">
        Thank you for placing your order with <strong>JV Indians</strong>. We’ve received your order and will process it soon.
      </p>

      <h3 style="color: #333;">📦 Order Details</h3>
      <ul style="list-style: none; padding-left: 0; font-size: 15px;">
        <li><strong>🧾 Product Code:</strong> ${productCode}</li>
        <li><strong>📞 Phone:</strong> ${phone}</li>
        <li><strong>📧 Email:</strong> ${email}</li>
        <li><strong>📦 Quantity:</strong> ${quantity}</li>
        <li><strong>🏠 Address:</strong> ${address}</li>
      </ul>

      <p style="font-size: 15px;">We’ll get back to you soon!</p>

      <p style="margin-top: 30px; font-size: 14px; color: #666;">
        Regards,<br/>
        <strong>JV Indians Team</strong>
      </p>
    </div>
  `
};


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('❌ Email error:', error);
        return res.status(500).json({ message: 'Order saved, but email failed to send.' });
      }
      res.status(200).json({ message: '✅ Order placed and confirmation email sent.' });
    });

  } catch (err) {
    console.error('❌ Order DB error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});


// ✅ 13 Rod Order API
app.post("/api/13rodorder", async (req, res) => {
  const { productCode, name, email, phone, quantity, address } = req.body;

  if (!productCode || !name || !email || !phone || !quantity || !address) {
    return res.status(400).json({ message: '⚠️ All fields are required.' });
  }

  try {
    await db.execute(
      'INSERT INTO orders_13rod (product_code, name, email, phone, quantity, address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [productCode, name, email, phone, quantity, address]
    );

    const mailOptions = {
  from: 'abhilashdeveloper07@gmail.com',
  to: email,
  subject: 'Order Confirmation - JV Indians',
  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #ddd; padding: 20px; border-radius: 8px; background-color: #f9f9f9;">
      <h2 style="color: #004080; text-align: center;">JV Indians - Order Confirmation</h2>

      <p style="font-size: 16px;">Hello <strong>${name}</strong>,</p>

      <p style="font-size: 15px;">
        Thank you for placing your order with <strong>JV Indians</strong>. We’ve received your order and will process it soon.
      </p>

      <h3 style="color: #333;">📦 Order Details</h3>
      <ul style="list-style: none; padding-left: 0; font-size: 15px;">
        <li><strong>🧾 Product Code:</strong> ${productCode}</li>
        <li><strong>📞 Phone:</strong> ${phone}</li>
        <li><strong>📧 Email:</strong> ${email}</li>
        <li><strong>📦 Quantity:</strong> ${quantity}</li>
        <li><strong>🏠 Address:</strong> ${address}</li>
      </ul>

      <p style="font-size: 15px;">We’ll get back to you soon!</p>

      <p style="margin-top: 30px; font-size: 14px; color: #666;">
        Regards,<br/>
        <strong>JV Indians Team</strong>
      </p>
    </div>
  `
};


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('❌ Email error:', error);
        return res.status(500).json({ message: 'Order saved, but email failed to send.' });
      }
      res.status(200).json({ message: '✅ Order placed and confirmation email sent.' });
    });

  } catch (err) {
    console.error('❌ Order DB error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});



// ✅ 15 Rod Order API
app.post("/api/15rodorder", async (req, res) => {
  const { productCode, name, email, phone, quantity, address } = req.body;

  if (!productCode || !name || !email || !phone || !quantity || !address) {
    return res.status(400).json({ message: '⚠️ All fields are required.' });
  }

  try {
    await db.execute(
      'INSERT INTO orders_15rod (product_code, name, email, phone, quantity, address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [productCode, name, email, phone, quantity, address]
    );

    const mailOptions = {
  from: 'abhilashdeveloper07@gmail.com',
  to: email,
  subject: 'Order Confirmation - JV Indians',
  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #ddd; padding: 20px; border-radius: 8px; background-color: #f9f9f9;">
      <h2 style="color: #004080; text-align: center;">JV Indians - Order Confirmation</h2>

      <p style="font-size: 16px;">Hello <strong>${name}</strong>,</p>

      <p style="font-size: 15px;">
        Thank you for placing your order with <strong>JV Indians</strong>. We’ve received your order and will process it soon.
      </p>

      <h3 style="color: #333;">📦 Order Details</h3>
      <ul style="list-style: none; padding-left: 0; font-size: 15px;">
        <li><strong>🧾 Product Code:</strong> ${productCode}</li>
        <li><strong>📞 Phone:</strong> ${phone}</li>
        <li><strong>📧 Email:</strong> ${email}</li>
        <li><strong>📦 Quantity:</strong> ${quantity}</li>
        <li><strong>🏠 Address:</strong> ${address}</li>
      </ul>

      <p style="font-size: 15px;">We’ll get back to you soon!</p>

      <p style="margin-top: 30px; font-size: 14px; color: #666;">
        Regards,<br/>
        <strong>JV Indians Team</strong>
      </p>
    </div>
  `
};


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('❌ Email error:', error);
        return res.status(500).json({ message: 'Order saved, but email failed to send.' });
      }
      res.status(200).json({ message: '✅ Order placed and confirmation email sent.' });
    });

  } catch (err) {
    console.error('❌ Order DB error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});



// ✅ 17 Rod Order API
app.post("/api/17rodorder", async (req, res) => {
  const { productCode, name, email, phone, quantity, address } = req.body;

  if (!productCode || !name || !email || !phone || !quantity || !address) {
    return res.status(400).json({ message: '⚠️ All fields are required.' });
  }

  try {
    await db.execute(
      'INSERT INTO orders_17rod (product_code, name, email, phone, quantity, address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [productCode, name, email, phone, quantity, address]
    );

    const mailOptions = {
  from: 'abhilashdeveloper07@gmail.com',
  to: email,
  subject: 'Order Confirmation - JV Indians',
  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #ddd; padding: 20px; border-radius: 8px; background-color: #f9f9f9;">
      <h2 style="color: #004080; text-align: center;">JV Indians - Order Confirmation</h2>

      <p style="font-size: 16px;">Hello <strong>${name}</strong>,</p>

      <p style="font-size: 15px;">
        Thank you for placing your order with <strong>JV Indians</strong>. We’ve received your order and will process it soon.
      </p>

      <h3 style="color: #333;">📦 Order Details</h3>
      <ul style="list-style: none; padding-left: 0; font-size: 15px;">
        <li><strong>🧾 Product Code:</strong> ${productCode}</li>
        <li><strong>📞 Phone:</strong> ${phone}</li>
        <li><strong>📧 Email:</strong> ${email}</li>
        <li><strong>📦 Quantity:</strong> ${quantity}</li>
        <li><strong>🏠 Address:</strong> ${address}</li>
      </ul>

      <p style="font-size: 15px;">We’ll get back to you soon!</p>

      <p style="margin-top: 30px; font-size: 14px; color: #666;">
        Regards,<br/>
        <strong>JV Indians Team</strong>
      </p>
    </div>
  `
};


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('❌ Email error:', error);
        return res.status(500).json({ message: 'Order saved, but email failed to send.' });
      }
      res.status(200).json({ message: '✅ Order placed and confirmation email sent.' });
    });

  } catch (err) {
    console.error('❌ Order DB error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});


// ✅ 21 Rod Order API
app.post("/api/21rodorder", async (req, res) => {
  const { productCode, name, email, phone, quantity, address } = req.body;

  if (!productCode || !name || !email || !phone || !quantity || !address) {
    return res.status(400).json({ message: '⚠️ All fields are required.' });
  }

  try {
    await db.execute(
      'INSERT INTO orders_21rod (product_code, name, email, phone, quantity, address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [productCode, name, email, phone, quantity, address]
    );

    const mailOptions = {
  from: 'abhilashdeveloper07@gmail.com',
  to: email,
  subject: 'Order Confirmation - JV Indians',
  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #ddd; padding: 20px; border-radius: 8px; background-color: #f9f9f9;">
      <h2 style="color: #004080; text-align: center;">JV Indians - Order Confirmation</h2>

      <p style="font-size: 16px;">Hello <strong>${name}</strong>,</p>

      <p style="font-size: 15px;">
        Thank you for placing your order with <strong>JV Indians</strong>. We’ve received your order and will process it soon.
      </p>

      <h3 style="color: #333;">📦 Order Details</h3>
      <ul style="list-style: none; padding-left: 0; font-size: 15px;">
        <li><strong>🧾 Product Code:</strong> ${productCode}</li>
        <li><strong>📞 Phone:</strong> ${phone}</li>
        <li><strong>📧 Email:</strong> ${email}</li>
        <li><strong>📦 Quantity:</strong> ${quantity}</li>
        <li><strong>🏠 Address:</strong> ${address}</li>
      </ul>

      <p style="font-size: 15px;">We’ll get back to you soon!</p>

      <p style="margin-top: 30px; font-size: 14px; color: #666;">
        Regards,<br/>
        <strong>JV Indians Team</strong>
      </p>
    </div>
  `
};


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('❌ Email error:', error);
        return res.status(500).json({ message: 'Order saved, but email failed to send.' });
      }
      res.status(200).json({ message: '✅ Order placed and confirmation email sent.' });
    });

  } catch (err) {
    console.error('❌ Order DB error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});



// ✅ 23 Rod Order API
app.post("/api/23rodorder", async (req, res) => {
  const { productCode, name, email, phone, quantity, address } = req.body;

  if (!productCode || !name || !email || !phone || !quantity || !address) {
    return res.status(400).json({ message: '⚠️ All fields are required.' });
  }

  try {
    await db.execute(
      'INSERT INTO orders_23rod (product_code, name, email, phone, quantity, address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [productCode, name, email, phone, quantity, address]
    );

    const mailOptions = {
  from: 'abhilashdeveloper07@gmail.com',
  to: email,
  subject: 'Order Confirmation - JV Indians',
  html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #ddd; padding: 20px; border-radius: 8px; background-color: #f9f9f9;">
      <h2 style="color: #004080; text-align: center;">JV Indians - Order Confirmation</h2>

      <p style="font-size: 16px;">Hello <strong>${name}</strong>,</p>

      <p style="font-size: 15px;">
        Thank you for placing your order with <strong>JV Indians</strong>. We’ve received your order and will process it soon.
      </p>

      <h3 style="color: #333;">📦 Order Details</h3>
      <ul style="list-style: none; padding-left: 0; font-size: 15px;">
        <li><strong>🧾 Product Code:</strong> ${productCode}</li>
        <li><strong>📞 Phone:</strong> ${phone}</li>
        <li><strong>📧 Email:</strong> ${email}</li>
        <li><strong>📦 Quantity:</strong> ${quantity}</li>
        <li><strong>🏠 Address:</strong> ${address}</li>
      </ul>

      <p style="font-size: 15px;">We’ll get back to you soon!</p>

      <p style="margin-top: 30px; font-size: 14px; color: #666;">
        Regards,<br/>
        <strong>JV Indians Team</strong>
      </p>
    </div>
  `
};


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('❌ Email error:', error);
        return res.status(500).json({ message: 'Order saved, but email failed to send.' });
      }
      res.status(200).json({ message: '✅ Order placed and confirmation email sent.' });
    });

  } catch (err) {
    console.error('❌ Order DB error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});


// ✅ Razorpay instance
const razorpay = new Razorpay({
  key_id: "rzp_test_nDpJ94SOo5HYvr",        // Replace with Razorpay key_id
  key_secret: "02oDE6wd2trJWVd4XH20PTkU" // Replace with Razorpay key_secret
});
// ✅ Create Razorpay Order
app.post("/create-order", async (req, res) => {
  const { amount } = req.body;

  const options = {
    amount: amount, // in paise
    currency: "INR",
    receipt: "jv_receipt_" + Math.floor(Math.random() * 10000),
    payment_capture: 1,
  };

  try {
    const order = await razorpay.orders.create(options);
    res.json({ orderId: order.id, amount: order.amount });
  } catch (err) {
    console.error("Order creation error:", err);
    res.status(500).send("Error creating Razorpay order");
  }
});

// ✅ Payment Success - Store in DB
app.post("/payment-success", async (req, res) => {
  const { name, email, amount, razorpay_payment_id } = req.body;

  try {
    const sql = `INSERT INTO payments (name, email, amount, payment_id, order_id) VALUES (?, ?, ?, ?, ?)`;
    await db.execute(sql, [name, email, amount, razorpay_payment_id, "N/A"]); // Use "N/A" if no order_id

    res.status(200).json({ message: "Payment stored in DB" });
  } catch (err) {
    console.error("DB Error:", err);
    res.status(500).send("Database insertion error");
  }
});



// ✅ Default route
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// ✅ Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
